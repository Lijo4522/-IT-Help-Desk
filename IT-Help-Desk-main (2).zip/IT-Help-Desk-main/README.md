# IT Help Desk & Asset Manager

Welcome! This is a complete Help Desk system that helps you track support tickets, manage computer parts (assets), and keep a log of where items are moved.

This guide is written specifically for beginners. You don't need to be an expert coder to get this running on your computer.

---

## 🚀 Quick Start Guide

### Step 1: Install Node.js (The Engine)

This application runs on **Node.js**. Think of it as the engine that powers the application.

1.  Go to the official website: [https://nodejs.org/](https://nodejs.org/)
2.  Download the **LTS (Long Term Support)** version (recommended for most users).
3.  Run the installer and follow the prompts (just click "Next" until it's done).
4.  **Verify it's installed**:
    *   Open your computer's terminal (Command Prompt on Windows, Terminal on Mac).
    *   Type `node -v` and press Enter. You should see a version number like `v18.x.x` or `v20.x.x`.

### Step 2: Download This Project

1.  Download the project files to your computer (if you haven't already).
2.  Unzip the folder if it's compressed.
3.  **Important**: Remember where you saved this folder!

### Step 3: Open the Terminal in the Project Folder

This is often the trickiest part for beginners. You need to tell your computer *where* the project is.

**On Windows:**
1.  Open the project folder in File Explorer.
2.  Click on the address bar at the top (where the folder path is).
3.  Type `cmd` and press **Enter**.
4.  A black window (Command Prompt) will open. It is now "inside" your project folder.

**On Mac:**
1.  Open the Terminal app.
2.  Type `cd ` (type `cd` followed by a space).
3.  Drag and drop the project folder from Finder into the Terminal window.
4.  Press **Enter**.

### Step 4: Install the "Parts" (Dependencies)

The application needs some extra software libraries to work (like the chart tool, the database tool, etc.). We call these "dependencies".

1.  In your terminal window, type the following command and press **Enter**:
    ```bash
    npm install
    ```
2.  You will see a lot of text scrolling. This is normal! It's downloading all the necessary parts from the internet.
3.  Wait until it stops and gives you a new command prompt line.

### Step 5: Start the App!

**The Easy Way (Windows Only):**
1. Find the file named `Start-HelpDesk.bat` in your project folder.
2. Double-click it! 
3. It will automatically start the server and open your web browser. *(Tip: Right-click this file and select "Send to > Desktop" to make a convenient shortcut).*

**The Manual Way (Mac/Linux/Windows):**
1.  Type this command and press **Enter**:
    ```bash
    npm run dev
    ```
2.  You should see a message saying something like:
    ```
    Server running on http://localhost:3000
    ```
3.  Open your web browser (Chrome, Edge, Firefox, etc.).
4.  Type `http://localhost:3000` in the address bar and press Enter.

**🎉 Congratulations! You are now running your own IT Help Desk system.**

---

## 🛠️ How to Use the System

### 1. Dashboard
This is your home screen. It shows you a quick summary:
- **Open Tickets**: How many support requests are waiting.
- **Low Stock**: Alerts for items that are running out.
- **Reports**: Buttons to download Excel reports (Weekly, Monthly, or Custom Dates).

### 2. Tickets
- Click **"New Ticket"** to record a problem (e.g., "Printer not working").
- You can set the priority (Low, Medium, High).
- Change the status (Open -> In Progress -> Closed) as you work on it.

### 3. Assets (Inventory)
- This is where you track your items (Laptops, RAM, Monitors).
- Click **"Add Asset"** to add a new item manually.
- Click **"Import"** to upload a CSV or Excel file with a list of items.
- You can switch between **Grid View** (cards) and **List View** (table).

### 4. Transfers
- Use this to record when you give an item to someone or move it to a new room.
- It automatically updates the quantity in your inventory!

---

## ❓ Troubleshooting (Common Issues)

**Q: I see an error: `'vite' is not recognized` or `'tsx' is not recognized`**
**A: This is the most common error!** It means the "dependencies" (software parts) are not installed yet.
1.  Close the error.
2.  In your terminal, type: `npm install`
3.  Press **Enter**.
4.  Wait for it to finish (it might take a few minutes).
5.  Then try `npm run build` or `npm run dev` again.

**Q: The command `npm` is not found.**
A: This means Node.js wasn't installed correctly. Try restarting your computer. If that doesn't work, reinstall Node.js from Step 1.

**Q: I see "EADDRINUSE: address already in use".**
A: This means port 3000 is busy. Maybe you have the app running in another window? Close other terminal windows and try again.

**Q: The database is empty!**
A: On the very first run, the system creates a file called `helpdesk.db`. It automatically adds some sample data so you can see how it looks. You can delete the sample data or add your own.

**Q: How do I stop the server?**
A: In the terminal window where the app is running, press **Ctrl + C** on your keyboard.

---

## 💻 For Developers (Technical Details)

If you want to modify the code:
- **Frontend**: React + Tailwind CSS (in `src/` folder)
- **Backend**: Node.js + Express (in `server.ts`)
- **Database**: SQLite (file: `helpdesk.db`)

To build for production (make it faster/optimized):
1. `npm run build`
2. `NODE_ENV=production npm run dev`
