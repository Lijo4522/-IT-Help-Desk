import express from 'express';
import { createServer as createViteServer } from 'vite';
import Database from 'better-sqlite3';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import fs from 'fs';
import multer from 'multer';
import * as XLSX from 'xlsx';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Initialize Database
const db = new Database('helpdesk.db');
db.pragma('journal_mode = WAL');

// Create Tables
db.exec(`
  CREATE TABLE IF NOT EXISTS tickets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'Open', -- Open, In Progress, Closed
    priority TEXT DEFAULT 'Medium', -- Low, Medium, High
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS assets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT NOT NULL, -- RAM, HDD, Monitor, etc.
    quantity INTEGER DEFAULT 0,
    min_quantity INTEGER DEFAULT 0,
    location TEXT,
    condition TEXT DEFAULT 'Good', -- New, Good, Fair, Poor, Broken
    status TEXT DEFAULT 'Available', -- Available, Assigned, In Repair, Retired
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS transfers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_id INTEGER NOT NULL,
    ticket_id INTEGER,
    quantity INTEGER NOT NULL,
    from_location TEXT,
    to_location TEXT,
    notes TEXT,
    transfer_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (asset_id) REFERENCES assets(id),
    FOREIGN KEY (ticket_id) REFERENCES tickets(id)
  );

  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT,
    department TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS ticket_comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id INTEGER NOT NULL,
    author TEXT NOT NULL,
    comment TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ticket_id) REFERENCES tickets(id)
  );
`);

// Check if new columns exist, if not add them (migration for existing db)
try {
  db.prepare('SELECT condition FROM assets LIMIT 1').get();
} catch (e) {
  db.exec("ALTER TABLE assets ADD COLUMN condition TEXT DEFAULT 'Good'");
  db.exec("ALTER TABLE assets ADD COLUMN status TEXT DEFAULT 'Available'");
}

try { db.exec("ALTER TABLE assets ADD COLUMN assigned_to_user_id INTEGER REFERENCES users(id)"); } catch (e) {}
try { db.exec("ALTER TABLE tickets ADD COLUMN requester_id INTEGER REFERENCES users(id)"); } catch (e) {}
try { db.exec("ALTER TABLE tickets ADD COLUMN resolved_at DATETIME"); } catch (e) {}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Ensure uploads directory exists
  const uploadDir = join(__dirname, 'uploads');
  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
  }

  // Configure Multer for file uploads
  const upload = multer({ dest: 'uploads/' });

  // API Routes
  
  app.post('/api/reset', (req, res) => {
    try {
      db.transaction(() => {
        db.exec('DELETE FROM transfers');
        db.exec('DELETE FROM ticket_comments');
        db.exec('DELETE FROM tickets');
        db.exec('DELETE FROM assets');
        db.exec('DELETE FROM users');
      })();
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Users
  app.get('/api/users', (req, res) => {
    const stmt = db.prepare('SELECT * FROM users ORDER BY name');
    res.json(stmt.all());
  });

  app.post('/api/users', (req, res) => {
    const { name, email, department } = req.body;
    const stmt = db.prepare('INSERT INTO users (name, email, department) VALUES (?, ?, ?)');
    const info = stmt.run(name, email, department);
    res.json({ id: info.lastInsertRowid });
  });

  app.get('/api/users/:id/assets', (req, res) => {
    const stmt = db.prepare('SELECT * FROM assets WHERE assigned_to_user_id = ? ORDER BY name');
    res.json(stmt.all(req.params.id));
  });

  // Ticket Comments
  app.get('/api/tickets/:id/comments', (req, res) => {
    const stmt = db.prepare('SELECT * FROM ticket_comments WHERE ticket_id = ? ORDER BY created_at ASC');
    res.json(stmt.all(req.params.id));
  });

  app.post('/api/tickets/:id/comments', (req, res) => {
    const { author, comment } = req.body;
    const stmt = db.prepare('INSERT INTO ticket_comments (ticket_id, author, comment) VALUES (?, ?, ?)');
    const info = stmt.run(req.params.id, author, comment);
    res.json({ id: info.lastInsertRowid });
  });

  // Tickets
  app.get('/api/tickets', (req, res) => {
    const stmt = db.prepare(`
      SELECT t.*, u.name as requester_name 
      FROM tickets t
      LEFT JOIN users u ON t.requester_id = u.id
      ORDER BY t.created_at DESC
    `);
    const tickets = stmt.all();
    res.json(tickets);
  });

  app.post('/api/tickets', (req, res) => {
    const { title, description, priority, requester_id } = req.body;
    const stmt = db.prepare('INSERT INTO tickets (title, description, priority, requester_id) VALUES (?, ?, ?, ?)');
    const info = stmt.run(title, description, priority || 'Medium', requester_id || null);
    res.json({ id: info.lastInsertRowid });
  });

  app.put('/api/tickets/:id', (req, res) => {
    const { status } = req.body;
    let stmt;
    if (status === 'Closed') {
      // Set resolved_at if it's being closed (and keep it if already closed)
      stmt = db.prepare('UPDATE tickets SET status = ?, updated_at = CURRENT_TIMESTAMP, resolved_at = COALESCE(resolved_at, CURRENT_TIMESTAMP) WHERE id = ?');
    } else {
      // Clear resolved_at if it's reopened
      stmt = db.prepare('UPDATE tickets SET status = ?, updated_at = CURRENT_TIMESTAMP, resolved_at = NULL WHERE id = ?');
    }
    stmt.run(status, req.params.id);
    res.json({ success: true });
  });

  // Assets
  app.get('/api/assets', (req, res) => {
    const stmt = db.prepare(`
      SELECT a.*, u.name as assigned_user_name 
      FROM assets a
      LEFT JOIN users u ON a.assigned_to_user_id = u.id
      ORDER BY a.name
    `);
    const assets = stmt.all();
    res.json(assets);
  });

  app.post('/api/assets', (req, res) => {
    const { name, category, quantity, min_quantity, location, condition, status, assigned_to_user_id } = req.body;
    const stmt = db.prepare('INSERT INTO assets (name, category, quantity, min_quantity, location, condition, status, assigned_to_user_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    const info = stmt.run(name, category, quantity, min_quantity, location, condition || 'Good', status || 'Available', assigned_to_user_id || null);
    res.json({ id: info.lastInsertRowid });
  });

  app.put('/api/assets/:id', (req, res) => {
    const { quantity, condition, status, location, assigned_to_user_id } = req.body;
    // Dynamic update based on provided fields
    const updates: string[] = [];
    const values: any[] = [];
    
    if (quantity !== undefined) { updates.push('quantity = ?'); values.push(quantity); }
    if (condition !== undefined) { updates.push('condition = ?'); values.push(condition); }
    if (status !== undefined) { updates.push('status = ?'); values.push(status); }
    if (location !== undefined) { updates.push('location = ?'); values.push(location); }
    if (assigned_to_user_id !== undefined) { updates.push('assigned_to_user_id = ?'); values.push(assigned_to_user_id || null); }
    
    if (updates.length > 0) {
      values.push(req.params.id);
      const stmt = db.prepare(`UPDATE assets SET ${updates.join(', ')} WHERE id = ?`);
      stmt.run(...values);
    }
    
    res.json({ success: true });
  });

  // Import Assets
  app.post('/api/assets/import', upload.single('file'), (req, res) => {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    try {
      const workbook = XLSX.readFile(req.file.path);
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const data = XLSX.utils.sheet_to_json(sheet);

      const insertStmt = db.prepare(`
        INSERT INTO assets (name, category, quantity, min_quantity, location, condition, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `);

      const importTx = db.transaction((rows: any[]) => {
        for (const row of rows) {
          // Map CSV/Excel columns to DB columns (case insensitive matching could be added)
          const name = row['Item'] || row['Name'] || row['name'] || 'Unknown Item';
          const category = row['Category'] || row['category'] || 'General';
          const quantity = parseInt(row['Quantity'] || row['quantity'] || '0');
          const min_quantity = parseInt(row['Min Quantity'] || row['min_quantity'] || '0');
          const location = row['Location'] || row['location'] || 'Unassigned';
          const condition = row['Condition'] || row['condition'] || 'Good';
          const status = row['Status'] || row['status'] || 'Available';

          insertStmt.run(name, category, quantity, min_quantity, location, condition, status);
        }
      });

      importTx(data);
      
      // Cleanup uploaded file
      fs.unlinkSync(req.file.path);
      
      res.json({ success: true, count: data.length });
    } catch (error: any) {
      console.error('Import error:', error);
      res.status(500).json({ error: 'Failed to process file: ' + error.message });
    }
  });

  // Transfers
  app.get('/api/transfers', (req, res) => {
    const stmt = db.prepare(`
      SELECT t.*, a.name as asset_name, tick.title as ticket_title 
      FROM transfers t 
      JOIN assets a ON t.asset_id = a.id 
      LEFT JOIN tickets tick ON t.ticket_id = tick.id
      ORDER BY t.transfer_date DESC
    `);
    const transfers = stmt.all();
    res.json(transfers);
  });

  app.post('/api/transfers', (req, res) => {
    const { asset_id, ticket_id, quantity, from_location, to_location, notes } = req.body;
    
    const transferTx = db.transaction(() => {
      // Record transfer
      const stmt = db.prepare('INSERT INTO transfers (asset_id, ticket_id, quantity, from_location, to_location, notes) VALUES (?, ?, ?, ?, ?, ?)');
      const info = stmt.run(asset_id, ticket_id, quantity, from_location, to_location, notes);
      
      // Update asset quantity
      const asset = db.prepare('SELECT quantity FROM assets WHERE id = ?').get(asset_id) as { quantity: number };
      const newQuantity = asset.quantity - quantity;
      db.prepare('UPDATE assets SET quantity = ? WHERE id = ?').run(newQuantity, asset_id);
      
      return info.lastInsertRowid;
    });

    try {
      const id = transferTx();
      res.json({ id });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Reports Data
  app.get('/api/reports/stats', (req, res) => {
    const openTickets = db.prepare("SELECT count(*) as count FROM tickets WHERE status != 'Closed'").get();
    const lowStock = db.prepare("SELECT count(*) as count FROM assets WHERE quantity <= min_quantity").get();
    const transfersThisMonth = db.prepare("SELECT count(*) as count FROM transfers WHERE strftime('%Y-%m', transfer_date) = strftime('%Y-%m', 'now')").get();
    
    // Weekly activity (last 7 days)
    const weeklyActivity = db.prepare(`
      SELECT date(created_at) as date, count(*) as count 
      FROM tickets 
      WHERE created_at >= date('now', '-7 days') 
      GROUP BY date(created_at)
    `).all();

    res.json({
      openTickets: (openTickets as any).count,
      lowStock: (lowStock as any).count,
      transfersThisMonth: (transfersThisMonth as any).count,
      weeklyActivity
    });
  });

  // Download Report
  app.get('/api/reports/download', (req, res) => {
    try {
      const type = req.query.type as string; // 'weekly', 'monthly', 'all', 'custom'
      const startDate = req.query.startDate as string;
      const endDate = req.query.endDate as string;
      
      let ticketsStmt = 'SELECT * FROM tickets';
      let transfersStmt = `
        SELECT t.*, a.name as asset_name, tick.title as ticket_title 
        FROM transfers t 
        JOIN assets a ON t.asset_id = a.id 
        LEFT JOIN tickets tick ON t.ticket_id = tick.id
      `;
      
      if (type === 'weekly') {
        ticketsStmt += " WHERE created_at >= date('now', '-7 days')";
        transfersStmt += " WHERE t.transfer_date >= date('now', '-7 days')";
      } else if (type === 'monthly') {
        ticketsStmt += " WHERE created_at >= date('now', '-30 days')";
        transfersStmt += " WHERE t.transfer_date >= date('now', '-30 days')";
      } else if (type === 'custom' && startDate && endDate) {
        ticketsStmt += " WHERE date(created_at) BETWEEN ? AND ?";
        transfersStmt += " WHERE date(t.transfer_date) BETWEEN ? AND ?";
      }

      const tickets = (type === 'custom' && startDate && endDate) 
        ? db.prepare(ticketsStmt).all(startDate, endDate)
        : db.prepare(ticketsStmt).all();

      const assets = db.prepare('SELECT * FROM assets').all(); // Always export current asset state
      
      const transfers = (type === 'custom' && startDate && endDate)
        ? db.prepare(transfersStmt).all(startDate, endDate)
        : db.prepare(transfersStmt).all();

      const wb = XLSX.utils.book_new();
      
      const ticketsSheet = XLSX.utils.json_to_sheet(tickets);
      XLSX.utils.book_append_sheet(wb, ticketsSheet, 'Tickets');
      
      const assetsSheet = XLSX.utils.json_to_sheet(assets);
      XLSX.utils.book_append_sheet(wb, assetsSheet, 'Assets');
      
      const transfersSheet = XLSX.utils.json_to_sheet(transfers);
      XLSX.utils.book_append_sheet(wb, transfersSheet, 'Transfers');

      const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
      
      res.setHeader('Content-Disposition', `attachment; filename="helpdesk_report_${type || 'full'}_${new Date().toISOString().split('T')[0]}.xlsx"`);
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.send(buf);
      
    } catch (err: any) {
      console.error('Report generation error:', err);
      res.status(500).send('Error generating report');
    }
  });

  // Vite middleware
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    app.use(express.static(join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
