@echo off
title IT Help Desk Server
color 0A

echo ===================================================
echo           IT HELP DESK ^& ASSET MANAGER
echo ===================================================
echo.
echo Starting the server in Production Mode for maximum stability...
echo.
echo IMPORTANT: Do NOT close this window! 
echo If you close this window, the Help Desk will stop working.
echo You can minimize it to get it out of the way.
echo.

:: Wait 2 seconds to ensure the server has time to start before opening the browser
timeout /t 2 /nobreak >nul

:: Open the default web browser to the app
start http://localhost:3000

:: Start the Node.js server in production mode
set NODE_ENV=production
npm run dev
