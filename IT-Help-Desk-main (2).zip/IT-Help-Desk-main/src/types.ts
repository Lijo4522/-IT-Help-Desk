export interface User {
  id: number;
  name: string;
  email: string;
  department: string;
  created_at: string;
}

export interface TicketComment {
  id: number;
  ticket_id: number;
  author: string;
  comment: string;
  created_at: string;
}

export interface Ticket {
  id: number;
  title: string;
  description: string;
  status: 'Open' | 'In Progress' | 'Closed';
  priority: 'Low' | 'Medium' | 'High';
  requester_id?: number;
  requester_name?: string;
  created_at: string;
  updated_at: string;
  resolved_at?: string;
}

export interface Asset {
  id: number;
  name: string;
  category: string;
  quantity: number;
  min_quantity: number;
  location: string;
  condition: 'New' | 'Good' | 'Fair' | 'Poor' | 'Broken';
  status: 'Available' | 'Assigned' | 'In Repair' | 'Retired';
  assigned_to_user_id?: number;
  assigned_user_name?: string;
  created_at: string;
}

export interface Transfer {
  id: number;
  asset_id: number;
  ticket_id?: number;
  quantity: number;
  from_location: string;
  to_location: string;
  notes: string;
  transfer_date: string;
  asset_name?: string;
  ticket_title?: string;
}

export interface Stats {
  openTickets: number;
  lowStock: number;
  transfersThisMonth: number;
  weeklyActivity: { date: string; count: number }[];
}
