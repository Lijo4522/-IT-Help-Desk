import { useState } from 'react';
import { LayoutDashboard, Ticket, Package, ArrowRightLeft, Menu, Users } from 'lucide-react';
import { SidebarItem } from './components/SidebarItem';
import Dashboard from './components/Dashboard';
import TicketList from './components/TicketList';
import AssetInventory from './components/AssetInventory';
import TransferLog from './components/TransferLog';
import UserList from './components/UserList';

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'tickets' | 'assets' | 'transfers' | 'users'>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex">
      {/* Sidebar */}
      <aside 
        className={`${
          isSidebarOpen ? 'w-64' : 'w-20'
        } bg-gray-950 border-r border-gray-800 transition-all duration-300 flex flex-col fixed h-full z-10`}
      >
        <div className="p-6 flex items-center justify-between">
          {isSidebarOpen && <h1 className="text-xl font-bold text-white tracking-tight">IT Help Desk</h1>}
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 hover:bg-gray-800 rounded-lg text-gray-400"
          >
            <Menu size={20} />
          </button>
        </div>

        <nav className="flex-1 px-4 space-y-2 mt-4">
          <SidebarItem 
            icon={LayoutDashboard} 
            label={isSidebarOpen ? "Dashboard" : ""} 
            active={activeTab === 'dashboard'} 
            onClick={() => setActiveTab('dashboard')} 
          />
          <SidebarItem 
            icon={Ticket} 
            label={isSidebarOpen ? "Tickets" : ""} 
            active={activeTab === 'tickets'} 
            onClick={() => setActiveTab('tickets')} 
          />
          <SidebarItem 
            icon={Package} 
            label={isSidebarOpen ? "Assets" : ""} 
            active={activeTab === 'assets'} 
            onClick={() => setActiveTab('assets')} 
          />
          <SidebarItem 
            icon={ArrowRightLeft} 
            label={isSidebarOpen ? "Transfers" : ""} 
            active={activeTab === 'transfers'} 
            onClick={() => setActiveTab('transfers')} 
          />
          <SidebarItem 
            icon={Users} 
            label={isSidebarOpen ? "Users" : ""} 
            active={activeTab === 'users'} 
            onClick={() => setActiveTab('users')} 
          />
        </nav>

        <div className="p-4 border-t border-gray-800">
          {isSidebarOpen && (
            <div className="text-xs text-gray-500 text-center">
              v1.0.0 • System Active
            </div>
          )}
        </div>
      </aside>

      {/* Main Content */}
      <main className={`flex-1 p-8 transition-all duration-300 ${isSidebarOpen ? 'ml-64' : 'ml-20'}`}>
        <div className="max-w-7xl mx-auto">
          {activeTab === 'dashboard' && <Dashboard />}
          {activeTab === 'tickets' && <TicketList />}
          {activeTab === 'assets' && <AssetInventory />}
          {activeTab === 'transfers' && <TransferLog />}
          {activeTab === 'users' && <UserList />}
        </div>
      </main>
    </div>
  );
}
