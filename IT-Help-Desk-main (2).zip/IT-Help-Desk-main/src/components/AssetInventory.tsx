import { useState, useEffect, FormEvent, useRef } from 'react';
import { Asset, User } from '../types';
import { Plus, Package, AlertTriangle, LayoutGrid, List, Upload, FileSpreadsheet } from 'lucide-react';

export default function AssetInventory() {
  const [assets, setAssets] = useState<Asset[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [newAsset, setNewAsset] = useState({ 
    name: '', 
    category: '', 
    quantity: 0, 
    min_quantity: 0, 
    location: '',
    condition: 'Good',
    status: 'Available',
    assigned_to_user_id: ''
  });
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadStatus, setUploadStatus] = useState<string>('');

  useEffect(() => {
    fetchAssets();
    fetchUsers();
  }, []);

  const fetchAssets = () => {
    fetch('/api/assets')
      .then(res => res.json())
      .then(data => setAssets(data));
  };

  const fetchUsers = () => {
    fetch('/api/users')
      .then(res => res.json())
      .then(data => setUsers(data));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    await fetch('/api/assets', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newAsset),
    });
    setIsModalOpen(false);
    setNewAsset({ 
      name: '', 
      category: '', 
      quantity: 0, 
      min_quantity: 0, 
      location: '',
      condition: 'Good',
      status: 'Available',
      assigned_to_user_id: ''
    });
    fetchAssets();
  };

  const handleImport = async (e: FormEvent) => {
    e.preventDefault();
    if (!fileInputRef.current?.files?.length) {
      setUploadStatus('Please select a file');
      return;
    }

    const formData = new FormData();
    formData.append('file', fileInputRef.current.files[0]);

    setUploadStatus('Uploading...');
    
    try {
      const res = await fetch('/api/assets/import', {
        method: 'POST',
        body: formData,
      });
      
      const data = await res.json();
      
      if (res.ok) {
        setUploadStatus(`Success! Imported ${data.count} items.`);
        setTimeout(() => {
          setIsImportModalOpen(false);
          setUploadStatus('');
          fetchAssets();
        }, 1500);
      } else {
        setUploadStatus(`Error: ${data.error}`);
      }
    } catch (err) {
      setUploadStatus('Upload failed.');
    }
  };

  const getConditionColor = (condition: string) => {
    switch (condition.toLowerCase()) {
      case 'new': return 'text-emerald-400 bg-emerald-400/10';
      case 'good': return 'text-blue-400 bg-blue-400/10';
      case 'fair': return 'text-yellow-400 bg-yellow-400/10';
      case 'poor': return 'text-orange-400 bg-orange-400/10';
      case 'broken': return 'text-red-400 bg-red-400/10';
      default: return 'text-gray-400 bg-gray-400/10';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'available': return 'text-emerald-400';
      case 'assigned': return 'text-indigo-400';
      case 'in repair': return 'text-yellow-400';
      case 'retired': return 'text-gray-500';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white">Asset Inventory</h2>
        <div className="flex items-center gap-4">
          <div className="flex bg-gray-800 rounded-lg p-1 border border-gray-700">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded ${viewMode === 'grid' ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:text-white'}`}
              title="Grid View"
            >
              <LayoutGrid size={20} />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded ${viewMode === 'list' ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:text-white'}`}
              title="List View"
            >
              <List size={20} />
            </button>
          </div>
          <button
            onClick={() => setIsImportModalOpen(true)}
            className="bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
          >
            <Upload size={18} />
            Import
          </button>
          <button
            onClick={() => setIsModalOpen(true)}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
          >
            <Plus size={18} />
            Add Asset
          </button>
        </div>
      </div>

      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {assets.map((asset) => (
            <div key={asset.id} className="bg-gray-800 rounded-xl border border-gray-700 p-6 hover:border-indigo-500/50 transition-colors">
              <div className="flex justify-between items-start mb-4">
                <div className="bg-gray-700/50 p-3 rounded-lg">
                  <Package className="text-indigo-400" size={24} />
                </div>
                <div className="flex flex-col items-end gap-2">
                  {asset.quantity <= asset.min_quantity && (
                    <div className="flex items-center gap-1 text-red-400 text-xs font-medium bg-red-400/10 px-2 py-1 rounded">
                      <AlertTriangle size={12} />
                      Low Stock
                    </div>
                  )}
                  <span className={`text-xs px-2 py-1 rounded font-medium ${getConditionColor(asset.condition)}`}>
                    {asset.condition}
                  </span>
                </div>
              </div>
              <h3 className="text-white font-bold text-lg mb-1">{asset.name}</h3>
              <p className="text-gray-400 text-sm mb-4">{asset.category}</p>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-500">Available / Qty</p>
                  <p className={`font-mono text-lg ${asset.quantity <= asset.min_quantity ? 'text-red-400' : 'text-white'}`}>
                    {asset.quantity}
                  </p>
                </div>
                <div>
                  <p className="text-gray-500">Assigned To / Loc</p>
                  <p className="text-white truncate" title={asset.assigned_user_name || asset.location}>
                    {asset.assigned_user_name || asset.location || 'Unassigned'}
                  </p>
                </div>
                <div className="col-span-2 border-t border-gray-700 pt-3 mt-1 flex justify-between items-center">
                   <span className="text-gray-500">Status:</span>
                   <span className={`font-medium ${getStatusColor(asset.status)}`}>{asset.status}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden">
          <table className="w-full text-left">
            <thead className="bg-gray-900/50 text-gray-400 text-sm uppercase">
              <tr>
                <th className="px-6 py-4">Item</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Condition</th>
                <th className="px-6 py-4">Available / Qty</th>
                <th className="px-6 py-4">Assigned To / Location</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700">
              {assets.map((asset) => (
                <tr key={asset.id} className="hover:bg-gray-700/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="text-white font-medium">{asset.name}</div>
                    <div className="text-gray-500 text-xs">{asset.category}</div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`font-medium ${getStatusColor(asset.status)}`}>{asset.status}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`text-xs px-2 py-1 rounded font-medium ${getConditionColor(asset.condition)}`}>
                      {asset.condition}
                    </span>
                  </td>
                  <td className="px-6 py-4 font-mono text-white">
                    {asset.quantity}
                    {asset.quantity <= asset.min_quantity && (
                      <span className="ml-2 text-red-400 text-xs"><AlertTriangle size={12} className="inline" /></span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-gray-300">
                    {asset.assigned_user_name || asset.location || 'Unassigned'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Add Asset Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-xl border border-gray-700 p-6 w-full max-w-md">
            <h3 className="text-xl font-bold text-white mb-4">Add New Asset</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-gray-400 text-sm mb-1">Asset Name</label>
                <input
                  type="text"
                  required
                  className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                  value={newAsset.name}
                  onChange={e => setNewAsset({...newAsset, name: e.target.value})}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-gray-400 text-sm mb-1">Category</label>
                  <input
                    type="text"
                    required
                    className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                    value={newAsset.category}
                    onChange={e => setNewAsset({...newAsset, category: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-gray-400 text-sm mb-1">Location</label>
                  <input
                    type="text"
                    required
                    className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                    value={newAsset.location}
                    onChange={e => setNewAsset({...newAsset, location: e.target.value})}
                  />
                </div>
              </div>
              <div>
                <label className="block text-gray-400 text-sm mb-1">Assigned To (User)</label>
                <select
                  className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                  value={newAsset.assigned_to_user_id}
                  onChange={e => setNewAsset({...newAsset, assigned_to_user_id: e.target.value})}
                >
                  <option value="">-- Unassigned --</option>
                  {users.map(u => (
                    <option key={u.id} value={u.id}>{u.name} ({u.department})</option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-gray-400 text-sm mb-1">Quantity</label>
                  <input
                    type="number"
                    required
                    className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                    value={newAsset.quantity}
                    onChange={e => setNewAsset({...newAsset, quantity: parseInt(e.target.value)})}
                  />
                </div>
                <div>
                  <label className="block text-gray-400 text-sm mb-1">Min Qty</label>
                  <input
                    type="number"
                    required
                    className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                    value={newAsset.min_quantity}
                    onChange={e => setNewAsset({...newAsset, min_quantity: parseInt(e.target.value)})}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-gray-400 text-sm mb-1">Condition</label>
                  <select
                    className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                    value={newAsset.condition}
                    onChange={e => setNewAsset({...newAsset, condition: e.target.value})}
                  >
                    <option>New</option>
                    <option>Good</option>
                    <option>Fair</option>
                    <option>Poor</option>
                    <option>Broken</option>
                  </select>
                </div>
                <div>
                  <label className="block text-gray-400 text-sm mb-1">Status</label>
                  <select
                    className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                    value={newAsset.status}
                    onChange={e => setNewAsset({...newAsset, status: e.target.value})}
                  >
                    <option>Available</option>
                    <option>Assigned</option>
                    <option>In Repair</option>
                    <option>Retired</option>
                  </select>
                </div>
              </div>
              <div className="flex justify-end gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-gray-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg"
                >
                  Add Asset
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Import Modal */}
      {isImportModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-xl border border-gray-700 p-6 w-full max-w-md">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <FileSpreadsheet className="text-emerald-400" />
              Import Assets
            </h3>
            <form onSubmit={handleImport} className="space-y-4">
              <div className="bg-gray-900/50 p-4 rounded-lg border border-gray-700 text-sm text-gray-400">
                <p className="mb-2">Upload a CSV or Excel file with the following headers:</p>
                <ul className="list-disc list-inside space-y-1 font-mono text-xs text-gray-500">
                  <li>Name (Required)</li>
                  <li>Category</li>
                  <li>Quantity</li>
                  <li>Location</li>
                  <li>Condition</li>
                  <li>Status</li>
                </ul>
              </div>
              
              <div>
                <label className="block text-gray-400 text-sm mb-1">Select File</label>
                <input
                  type="file"
                  ref={fileInputRef}
                  accept=".csv, .xlsx, .xls"
                  className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-600 file:text-white hover:file:bg-indigo-700"
                />
              </div>

              {uploadStatus && (
                <div className={`text-sm ${uploadStatus.includes('Error') || uploadStatus.includes('failed') ? 'text-red-400' : 'text-emerald-400'}`}>
                  {uploadStatus}
                </div>
              )}

              <div className="flex justify-end gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => {
                    setIsImportModalOpen(false);
                    setUploadStatus('');
                  }}
                  className="px-4 py-2 text-gray-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg"
                >
                  Upload & Import
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
