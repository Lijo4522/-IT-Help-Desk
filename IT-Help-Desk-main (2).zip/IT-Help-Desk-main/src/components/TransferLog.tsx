import { useState, useEffect, FormEvent } from 'react';
import { Transfer, Asset, Ticket } from '../types';
import { ArrowRightLeft, History } from 'lucide-react';

export default function TransferLog() {
  const [transfers, setTransfers] = useState<Transfer[]>([]);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newTransfer, setNewTransfer] = useState({
    asset_id: '',
    ticket_id: '',
    quantity: 1,
    from_location: '',
    to_location: '',
    notes: ''
  });

  useEffect(() => {
    fetchTransfers();
    fetchAssets();
    fetchTickets();
  }, []);

  const fetchTransfers = () => {
    fetch('/api/transfers')
      .then(res => res.json())
      .then(data => setTransfers(data));
  };

  const fetchAssets = () => {
    fetch('/api/assets')
      .then(res => res.json())
      .then(data => setAssets(data));
  };

  const fetchTickets = () => {
    fetch('/api/tickets')
      .then(res => res.json())
      .then(data => setTickets(data));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    await fetch('/api/transfers', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...newTransfer,
        asset_id: parseInt(newTransfer.asset_id),
        ticket_id: newTransfer.ticket_id ? parseInt(newTransfer.ticket_id) : null
      }),
    });
    setIsModalOpen(false);
    setNewTransfer({
      asset_id: '',
      ticket_id: '',
      quantity: 1,
      from_location: '',
      to_location: '',
      notes: ''
    });
    fetchTransfers();
    // Refresh assets to show updated quantity
    fetchAssets(); 
  };

  const handleAssetSelect = (assetId: string) => {
    const asset = assets.find(a => a.id === parseInt(assetId));
    setNewTransfer({
      ...newTransfer,
      asset_id: assetId,
      from_location: asset ? asset.location : ''
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white">Transfer Log</h2>
        <button
          onClick={() => setIsModalOpen(true)}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
        >
          <ArrowRightLeft size={18} />
          New Transfer
        </button>
      </div>

      <div className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-gray-900/50 text-gray-400 text-sm uppercase">
            <tr>
              <th className="px-6 py-4">Date</th>
              <th className="px-6 py-4">Asset</th>
              <th className="px-6 py-4">Qty</th>
              <th className="px-6 py-4">From / To</th>
              <th className="px-6 py-4">Related Ticket</th>
              <th className="px-6 py-4">Notes</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-700">
            {transfers.map((transfer) => (
              <tr key={transfer.id} className="hover:bg-gray-700/50 transition-colors">
                <td className="px-6 py-4 text-gray-400 text-sm">
                  {new Date(transfer.transfer_date).toLocaleDateString()}
                </td>
                <td className="px-6 py-4 text-white font-medium">
                  {transfer.asset_name}
                </td>
                <td className="px-6 py-4 font-mono text-indigo-400">
                  {transfer.quantity}
                </td>
                <td className="px-6 py-4 text-sm">
                  <div className="flex flex-col gap-1">
                    <span className="text-gray-400">From: <span className="text-gray-300">{transfer.from_location}</span></span>
                    <span className="text-gray-400">To: <span className="text-white">{transfer.to_location}</span></span>
                  </div>
                </td>
                <td className="px-6 py-4 text-sm text-indigo-300">
                  {transfer.ticket_title || '-'}
                </td>
                <td className="px-6 py-4 text-gray-500 text-sm italic">
                  {transfer.notes}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-xl border border-gray-700 p-6 w-full max-w-md">
            <h3 className="text-xl font-bold text-white mb-4">Record Transfer</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-gray-400 text-sm mb-1">Asset</label>
                <select
                  required
                  className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                  value={newTransfer.asset_id}
                  onChange={e => handleAssetSelect(e.target.value)}
                >
                  <option value="">Select Asset...</option>
                  {assets.map(a => (
                    <option key={a.id} value={a.id}>{a.name} (Qty: {a.quantity})</option>
                  ))}
                </select>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-gray-400 text-sm mb-1">Quantity</label>
                  <input
                    type="number"
                    required
                    min="1"
                    className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                    value={newTransfer.quantity}
                    onChange={e => setNewTransfer({...newTransfer, quantity: parseInt(e.target.value)})}
                  />
                </div>
                <div>
                  <label className="block text-gray-400 text-sm mb-1">Related Ticket (Opt)</label>
                  <select
                    className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                    value={newTransfer.ticket_id}
                    onChange={e => setNewTransfer({...newTransfer, ticket_id: e.target.value})}
                  >
                    <option value="">None</option>
                    {tickets.filter(t => t.status !== 'Closed').map(t => (
                      <option key={t.id} value={t.id}>#{t.id} - {t.title}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-gray-400 text-sm mb-1">From Location</label>
                  <input
                    type="text"
                    required
                    className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                    value={newTransfer.from_location}
                    onChange={e => setNewTransfer({...newTransfer, from_location: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-gray-400 text-sm mb-1">To Location</label>
                  <input
                    type="text"
                    required
                    className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                    value={newTransfer.to_location}
                    onChange={e => setNewTransfer({...newTransfer, to_location: e.target.value})}
                  />
                </div>
              </div>

              <div>
                <label className="block text-gray-400 text-sm mb-1">Notes</label>
                <textarea
                  className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500 h-20"
                  value={newTransfer.notes}
                  onChange={e => setNewTransfer({...newTransfer, notes: e.target.value})}
                />
              </div>

              <div className="flex justify-end gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-gray-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg"
                >
                  Record Transfer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
