import { useState, useEffect, FormEvent } from 'react';
import { User, Asset } from '../types';
import { Users, Plus, Package, X } from 'lucide-react';

export default function UserList() {
  const [users, setUsers] = useState<User[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newUser, setNewUser] = useState({ name: '', email: '', department: '' });
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [userAssets, setUserAssets] = useState<Asset[]>([]);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = () => {
    fetch('/api/users')
      .then(res => res.json())
      .then(data => setUsers(data));
  };

  const fetchUserAssets = (userId: number) => {
    fetch(`/api/users/${userId}/assets`)
      .then(res => res.json())
      .then(data => setUserAssets(data));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    await fetch('/api/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newUser),
    });
    setIsModalOpen(false);
    setNewUser({ name: '', email: '', department: '' });
    fetchUsers();
  };

  const handleUserClick = (user: User) => {
    setSelectedUser(user);
    fetchUserAssets(user.id);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <Users className="text-indigo-400" />
          Users & Employees
        </h2>
        <button
          onClick={() => setIsModalOpen(true)}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
        >
          <Plus size={18} />
          Add User
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* User List */}
        <div className="lg:col-span-1 bg-gray-800 rounded-xl border border-gray-700 overflow-hidden">
          <div className="p-4 border-b border-gray-700 bg-gray-900/50">
            <h3 className="text-lg font-medium text-white">Directory</h3>
          </div>
          <div className="divide-y divide-gray-700 max-h-[600px] overflow-y-auto">
            {users.map((user) => (
              <div 
                key={user.id} 
                onClick={() => handleUserClick(user)}
                className={`p-4 cursor-pointer transition-colors ${selectedUser?.id === user.id ? 'bg-indigo-900/30 border-l-4 border-indigo-500' : 'hover:bg-gray-700/50 border-l-4 border-transparent'}`}
              >
                <div className="font-medium text-white">{user.name}</div>
                <div className="text-sm text-gray-400">{user.department}</div>
                <div className="text-xs text-gray-500 mt-1">{user.email}</div>
              </div>
            ))}
            {users.length === 0 && (
              <div className="p-8 text-center text-gray-500">No users found.</div>
            )}
          </div>
        </div>

        {/* User Profile & Assets */}
        <div className="lg:col-span-2">
          {selectedUser ? (
            <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h3 className="text-2xl font-bold text-white">{selectedUser.name}</h3>
                  <p className="text-gray-400">{selectedUser.department} • {selectedUser.email}</p>
                </div>
                <div className="bg-indigo-900/50 text-indigo-300 px-3 py-1 rounded-full text-sm font-medium flex items-center gap-2">
                  <Package size={16} />
                  {userAssets.length} Assets Assigned
                </div>
              </div>

              <h4 className="text-lg font-medium text-white mb-4 border-b border-gray-700 pb-2">Assigned Assets</h4>
              
              {userAssets.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {userAssets.map(asset => (
                    <div key={asset.id} className="bg-gray-900 p-4 rounded-lg border border-gray-700">
                      <div className="flex justify-between items-start">
                        <div className="font-medium text-white">{asset.name}</div>
                        <span className="text-xs px-2 py-1 bg-gray-800 rounded text-gray-300">{asset.category}</span>
                      </div>
                      <div className="text-sm text-gray-400 mt-2">
                        Condition: <span className="text-gray-300">{asset.condition}</span>
                      </div>
                      <div className="text-sm text-gray-400">
                        Qty: <span className="text-gray-300">{asset.quantity}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 bg-gray-900/50 rounded-lg border border-gray-700 border-dashed">
                  <Package size={48} className="mx-auto text-gray-600 mb-3" />
                  <p className="text-gray-400">No assets currently assigned to this user.</p>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-gray-800 rounded-xl border border-gray-700 p-12 text-center h-full flex flex-col items-center justify-center">
              <Users size={64} className="text-gray-600 mb-4" />
              <h3 className="text-xl font-medium text-gray-300">Select a User</h3>
              <p className="text-gray-500 mt-2">Click on a user from the directory to view their profile and assigned assets.</p>
            </div>
          )}
        </div>
      </div>

      {/* Add User Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-xl border border-gray-700 p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold text-white">Add New User</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-white">
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-gray-400 text-sm mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                  value={newUser.name}
                  onChange={e => setNewUser({...newUser, name: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-gray-400 text-sm mb-1">Email Address</label>
                <input
                  type="email"
                  className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                  value={newUser.email}
                  onChange={e => setNewUser({...newUser, email: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-gray-400 text-sm mb-1">Department</label>
                <input
                  type="text"
                  className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-indigo-500"
                  value={newUser.department}
                  onChange={e => setNewUser({...newUser, department: e.target.value})}
                />
              </div>
              <div className="flex justify-end gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-gray-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg"
                >
                  Save User
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
