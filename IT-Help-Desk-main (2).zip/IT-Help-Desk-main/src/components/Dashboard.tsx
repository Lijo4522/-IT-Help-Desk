import { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Stats } from '../types';
import { AlertCircle, CheckCircle, ArrowRightLeft, Package, Download, FileText, Calendar, Trash2, AlertTriangle } from 'lucide-react';

export default function Dashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [showCustomRange, setShowCustomRange] = useState(false);
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  const [showResetModal, setShowResetModal] = useState(false);
  const [isResetting, setIsResetting] = useState(false);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = () => {
    fetch('/api/reports/stats')
      .then(res => res.json())
      .then(data => setStats(data));
  };

  const downloadReport = (type: 'weekly' | 'monthly' | 'all' | 'custom') => {
    let url = `/api/reports/download?type=${type}`;
    if (type === 'custom') {
      if (!dateRange.start || !dateRange.end) {
        alert('Please select both start and end dates');
        return;
      }
      url += `&startDate=${dateRange.start}&endDate=${dateRange.end}`;
    }
    window.location.href = url;
    if (type === 'custom') setShowCustomRange(false);
  };

  const handleResetData = async () => {
    setIsResetting(true);
    try {
      const res = await fetch('/api/reset', { method: 'POST' });
      if (res.ok) {
        setShowResetModal(false);
        fetchStats();
        // Force reload to clear state in other components
        window.location.reload();
      } else {
        console.error('Failed to reset data');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsResetting(false);
    }
  };

  if (!stats) return <div className="p-8 text-white">Loading stats...</div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <h2 className="text-2xl font-bold text-white">Dashboard Overview</h2>
        <div className="flex flex-wrap gap-2 relative">
          <button
            onClick={() => downloadReport('weekly')}
            className="bg-gray-800 hover:bg-gray-700 text-gray-200 px-3 py-2 rounded-lg flex items-center gap-2 text-sm border border-gray-700 transition-colors"
          >
            <FileText size={16} />
            Weekly
          </button>
          <button
            onClick={() => downloadReport('monthly')}
            className="bg-gray-800 hover:bg-gray-700 text-gray-200 px-3 py-2 rounded-lg flex items-center gap-2 text-sm border border-gray-700 transition-colors"
          >
            <FileText size={16} />
            Monthly
          </button>
          <div className="relative">
            <button
              onClick={() => setShowCustomRange(!showCustomRange)}
              className={`bg-gray-800 hover:bg-gray-700 text-gray-200 px-3 py-2 rounded-lg flex items-center gap-2 text-sm border border-gray-700 transition-colors ${showCustomRange ? 'bg-gray-700 ring-2 ring-indigo-500' : ''}`}
            >
              <Calendar size={16} />
              Custom Range
            </button>
            
            {showCustomRange && (
              <div className="absolute right-0 mt-2 p-4 bg-gray-800 rounded-xl border border-gray-700 shadow-xl z-50 w-72">
                <h4 className="text-white font-medium mb-3">Select Date Range</h4>
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs text-gray-400 mb-1">Start Date</label>
                    <input 
                      type="date" 
                      className="w-full bg-gray-900 border border-gray-600 rounded px-2 py-1 text-white text-sm"
                      value={dateRange.start}
                      onChange={(e) => setDateRange({...dateRange, start: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-400 mb-1">End Date</label>
                    <input 
                      type="date" 
                      className="w-full bg-gray-900 border border-gray-600 rounded px-2 py-1 text-white text-sm"
                      value={dateRange.end}
                      onChange={(e) => setDateRange({...dateRange, end: e.target.value})}
                    />
                  </div>
                  <button
                    onClick={() => downloadReport('custom')}
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-2 rounded-lg text-sm mt-2 transition-colors flex items-center justify-center gap-2"
                  >
                    <Download size={14} />
                    Download Report
                  </button>
                </div>
              </div>
            )}
          </div>
          <button
            onClick={() => downloadReport('all')}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-2 rounded-lg flex items-center gap-2 text-sm transition-colors"
          >
            <Download size={16} />
            Export All
          </button>
          <button
            onClick={() => setShowResetModal(true)}
            className="bg-red-600/20 hover:bg-red-600/30 text-red-400 border border-red-500/30 px-3 py-2 rounded-lg flex items-center gap-2 text-sm transition-colors ml-2"
          >
            <Trash2 size={16} />
            Reset Data
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gray-800 p-6 rounded-xl border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Open Tickets</p>
              <p className="text-3xl font-bold text-white mt-1">{stats.openTickets}</p>
            </div>
            <div className="bg-indigo-500/20 p-3 rounded-lg">
              <AlertCircle className="text-indigo-400" size={24} />
            </div>
          </div>
        </div>

        <div className="bg-gray-800 p-6 rounded-xl border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Low Stock Alerts</p>
              <p className="text-3xl font-bold text-white mt-1">{stats.lowStock}</p>
            </div>
            <div className="bg-red-500/20 p-3 rounded-lg">
              <Package className="text-red-400" size={24} />
            </div>
          </div>
        </div>

        <div className="bg-gray-800 p-6 rounded-xl border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Transfers (Month)</p>
              <p className="text-3xl font-bold text-white mt-1">{stats.transfersThisMonth}</p>
            </div>
            <div className="bg-emerald-500/20 p-3 rounded-lg">
              <ArrowRightLeft className="text-emerald-400" size={24} />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gray-800 p-6 rounded-xl border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">Weekly Ticket Activity</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={stats.weeklyActivity}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="date" stroke="#9CA3AF" />
              <YAxis stroke="#9CA3AF" />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1F2937', border: 'none', borderRadius: '8px' }}
                itemStyle={{ color: '#fff' }}
              />
              <Bar dataKey="count" fill="#6366F1" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Reset Confirmation Modal */}
      {showResetModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-xl border border-red-500/30 p-6 w-full max-w-md shadow-2xl">
            <div className="flex items-center gap-3 text-red-400 mb-4">
              <AlertTriangle size={28} />
              <h3 className="text-xl font-bold text-white">Reset All Data?</h3>
            </div>
            <p className="text-gray-300 mb-6 leading-relaxed">
              Are you sure you want to delete all data? This will permanently erase all <strong className="text-white">Tickets, Assets, Users, Comments, and Transfers</strong>. This action cannot be undone.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowResetModal(false)}
                disabled={isResetting}
                className="px-4 py-2 text-gray-400 hover:text-white transition-colors disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={handleResetData}
                disabled={isResetting}
                className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition-colors flex items-center gap-2 disabled:opacity-50"
              >
                {isResetting ? 'Resetting...' : 'Yes, Delete Everything'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
